package MJP.MVP.giaohangModel;

import java.sql.Date;

public class KhachHang {
	public String maKH;
	public String tenKH;
	public String diaChi;
	public Date ngaySinh;
	public String gioiTinh;
	public String sdt;
	public KhachHang() {
		
	}
	public KhachHang(String maKH, String tenKH, String diaChi, Date ngaySinh, String gioiTinh, String sdt) {
		super();
		this.maKH = maKH;
		this.tenKH = tenKH;
		this.diaChi = diaChi;
		this.ngaySinh = ngaySinh;
		this.gioiTinh = gioiTinh;
		this.sdt = sdt;
	}
	@Override
	public String toString() {
		return "modelKH [maKH=" + maKH + ", tenKH=" + tenKH + ", diaChi=" + diaChi + ", ngaySinh=" + ngaySinh
				+ ", gioiTinh=" + gioiTinh + ", sdt=" + sdt + "]";
	}
	public String getMaKH() {
		return maKH;
	}
	public void setMaKH(String maKH) {
		this.maKH = maKH;
	}
	public String getTenKH() {
		return tenKH;
	}
	public void setTenKH(String tenKH) {
		this.tenKH = tenKH;
	}
	public String getDiaChi() {
		return diaChi;
	}
	public void setDiaChi(String diaChi) {
		this.diaChi = diaChi;
	}
	public Date getNgaySinh() {
		return ngaySinh;
	}
	public void setNgaySinh(Date ngaySinh) {
		this.ngaySinh = ngaySinh;
	}
	public String getGioiTinh() {
		return gioiTinh;
	}
	public void setGioiTinh(String gioiTinh) {
		this.gioiTinh = gioiTinh;
	}
	public String getSdt() {
		return sdt;
	}
	public void setSdt(String sdt) {
		this.sdt = sdt;
	}
	
	
}

