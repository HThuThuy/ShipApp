package MJP.MVP.giaohangModel;

public class ChiTietDonHang {
private String maDH,maChiTietDH;
private float trongLuong;
private int soLuong;
private  double donGia;
private double thanhTien;
@Override
public String toString() {
	return "Chi_tiet_don_hang [maDH=" + maDH + ", maChiTietDH=" + maChiTietDH + ", trongLuong=" + trongLuong
			+ ", soLuong=" + soLuong + ", donGia=" + donGia + ", thanhTien=" + thanhTien + "]";
}
public ChiTietDonHang(String maDH, String maChiTietDH, float trongLuong, int soLuong, double donGia,
		double thanhTien) {
	super();
	this.maDH = maDH;
	this.maChiTietDH = maChiTietDH;
	this.trongLuong = trongLuong;
	this.soLuong = soLuong;
	this.donGia = donGia;
	this.thanhTien = thanhTien;
}
public ChiTietDonHang() {
	super();
}
public String getMaDH() {
	return maDH;
}
public void setMaDH(String maDH) {
	this.maDH = maDH;
}
public String getMaChiTietDH() {
	return maChiTietDH;
}
public void setMaChiTietDH(String maChiTietDH) {
	this.maChiTietDH = maChiTietDH;
}
public float getTrongLuong() {
	return trongLuong;
}
public void setTrongLuong(float trongLuong) {
	this.trongLuong = trongLuong;
}
public int getSoLuong() {
	return soLuong;
}
public void setSoLuong(int soLuong) {
	this.soLuong = soLuong;
}
public double getDonGia() {
	return donGia;
}
public void setDonGia(double donGia) {
	this.donGia = donGia;
}
public double getThanhTien() {
	return thanhTien;
}
public void setThanhTien(double thanhTien) {
	this.thanhTien = thanhTien;
}

}