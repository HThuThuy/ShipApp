package MJP.MVP.giaohangModel;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.PseudoColumnUsage;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.spec.DHGenParameterSpec;
import javax.print.attribute.HashDocAttributeSet;

import MJP.MVP.giaohang.ConnectionUtil;
import MJP.MVP.giaohangMenu.Validate;



public class ShipperDAO {
	public List<String> list2 = new ArrayList<>();
	/**
	 * Dang ky tai khoan Shipper moi
	 * @param shipper
	 * @param con
	 * @return
	 * @throws SQLException
	 */
	public Shipper insertShipper(Shipper shipper, Connection con) throws SQLException {
		Connection conn = ConnectionUtil.getConnection();
		String sql = "INSERT INTO SHIPPER VALUES (?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement preparedStatement = con.prepareStatement(sql);
		preparedStatement.setString(1, shipper.getMaShipper());
		preparedStatement.setString(2, shipper.getTenShipper());
		preparedStatement.setString(3, shipper.getDiaChi());
		preparedStatement.setDate(4, shipper.getNgaySinh());
		preparedStatement.setString(5, shipper.getGioiTinh());
		preparedStatement.setString(6, shipper.getSdt());
		preparedStatement.setString(7, shipper.getEmail());
		preparedStatement.setString(8, shipper.getTruong());
		preparedStatement.setString(9, shipper.getLop());
		preparedStatement.setString(10, "");
		if (preparedStatement.executeUpdate() > 0) {
			System.out.println("Dang ky thanh cong");
		} else {
			System.out.println("Dang ky that bai");
		}
		return shipper;
	}
/**
 * Tim kiem don hang theo ID khi dang nhap
 * @param maSP
 * @param con
 * @throws SQLException
 */
	public void getDonhangbyid(String maSP, Connection con) throws SQLException {
		String sql = "SELECT maDH,maKH,maShipper,tenMonHang,tenNguoiNhan FROM DON_HANG \n" + "WHERE maShipper = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		List<DonHang> list = new ArrayList<>();
		ps.setString(1, maSP);
		ResultSet rs = ps.executeQuery();
		DonHang dh = new DonHang();
		while (rs.next()) {
			dh = new DonHang();
			dh.setMaDH(rs.getString("maDH"));
			dh.setMaKH(rs.getString("maKH"));
			dh.setMaShipper(rs.getString("maShipper"));
			dh.setTenMonHang(rs.getString("tenMonHang"));
			dh.setTenNguoiNhan(rs.getString("tenNguoiNhan"));
			list.add(dh);
			System.out.println(dh);

		}
		if (dh.getMaShipper() == null) {
			System.out.println("Khong co don nao phu hop voi dieu kien");
			System.out.println("=================================");
		}
		ps.close();
		rs.close();

	}
/**
 * So lan giao hang theo maShipper luc dang nhap
 * @param maSP
 * @param con
 * @throws SQLException
 */
	public void solanGH(String maSP, Connection con) throws SQLException {
		String sql = "SELECT maShipper, COUNT(maDH) as Solangiao FROM DON_HANG \n" + "WHERE maShipper = ?\n"
				+ "GROUP BY maShipper";
		PreparedStatement ps = con.prepareStatement(sql);
		List<DonHang> list = new ArrayList<>();
		ps.setString(1, maSP);
		ResultSet rs = ps.executeQuery();
		DonHang dh = new DonHang();
		int count = 0;
		while (rs.next()) {
			dh = new DonHang();
			String maShipper = rs.getString("maShipper");
			int Solangiao = rs.getInt("Solangiao");
			System.out.println("maShipper: " + maShipper + "\tSolangiao: " + Solangiao);
			count++;
		}
		if (count == 0) {
			System.out.println("Chua co don nao");
		}

	}
/**
 * So lan shipper huy don
 * @param maSP
 * @param con
 * @throws SQLException
 */
	public void solanhuydon(String maSP, Connection con) throws SQLException {
		String sql = "SELECT maShipper, COUNT(maDH) as Solanhuy FROM DON_HANG \n"
				+ "WHERE maShipper = ? AND trangThaiGiaoHang = 'Da huy' \n" + "GROUP BY maShipper";
		PreparedStatement ps = con.prepareStatement(sql);
		List<DonHang> list = new ArrayList<>();
		ps.setString(1, maSP);
		ResultSet rs = ps.executeQuery();
		DonHang dh = new DonHang();
		int count = 0;
		while (rs.next()) {
			dh = new DonHang();
			String maShipper = rs.getString("maShipper");
			int Solanhuy = rs.getInt("Solanhuy");
			System.out.println("maShipper: " + maShipper + "\tSolan: " + Solanhuy);
			count++;

		}
		if (count == 0) {
			System.out.println("Chua co don nao");
		}

	}
/**
 * Thay doi trang thai don hang khi giao
 * @param dh
 * @param con
 * @return
 * @throws SQLException
 */
	public DonHang updateTrangThaiGH(DonHang dh, Connection con) throws SQLException {
		Connection conn = ConnectionUtil.getConnection();
		String sql = "UPDATE DON_HANG SET trangThaiGiaoHang = ? WHERE maDH= ? AND maShipper = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps = conn.prepareStatement(sql);
		ps.setString(1, dh.getTrangThaiGiaoHang());
		ps.setString(2, dh.getMaDH());
		ps.setString(3, dh.getMaShipper());
		if (ps.executeUpdate() > 0) {
			System.out.println("Update thanh cong");
		} else {
			System.out.println("Update that bai");
		}
		return dh;
	}

//public List<Don_hang>getall (Connection con) throws SQLException{
//	Don_hang dh = new Don_hang();
//	String sql = "SELECT * FROM DON_HANG WHERE maShipper = null ";
//	PreparedStatement ps = con.prepareStatement(sql);
//	List<Don_hang> list = new ArrayList<Don_hang>();
//	ResultSet rs = ps.executeQuery();
//	while(rs.next()) {
//		dh = new Don_hang();
//		dh.setMaDH(rs.getString("maDH"));
//		dh.setMaKH(rs.getString("maKH"));
//		dh.setDiaChiGH(rs.getString("diaChi"));
//		dh.setTenMonHang(rs.getString("tenMonHang"));
//		dh.setSdt(rs.getString("sdt"));
//		dh.setTenNguoiNhan(rs.getString("tenNguoiNhan"));
//		dh.setTrangThaiDH(rs.getString("trangThaiPheDuyet"));
//		dh.setTrangThaiGH(rs.getString("trangThaiDonHang"));
//		dh.setMaShipper(rs.getString("maShipper"));
//		list.add(dh);
//		System.out.println(dh);
//	}
//	ps.close();
//	rs.close();
//	return list;
//}
	/**
	 * Check trung ID o database
	 * @param id
	 * @param con
	 * @return
	 * @throws SQLException
	 */
	public boolean checkExitShipper(String id, Connection con) throws SQLException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		Shipper shipper = null;

		try {
			// Tạo prepared statement với câu truy vấn
			ps = con.prepareStatement("SELECT * FROM SHIPPER WHERE maShipper = ?");
			// Thiết lập giá trị tham số của câu truy vấn
			ps.setString(1, id);
			// Thực thi câu truy vấn và lấy kết quả
			rs = ps.executeQuery();

			// Nếu kết quả không rỗng thì lấy thông tin Shipper từ ResultSet
			if (rs.isBeforeFirst()) {
				return true;
			}
			return false;
		} finally {
			// Giải phóng tài nguyên
			if (rs != null)
				rs.close();
			if (ps != null)
				ps.close();
		}

	}
/**
 * Hien thi ten Shipper khi dang nhap xong
 * @param maSP
 * @param con
 * @throws SQLException
 */
	public void tenShipper(String maSP, Connection con) throws SQLException {
		String sql = "SELECT tenShipper FROM SHIPPER WHERE maShipper = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		List<Shipper> list = new ArrayList<>();
		ps.setString(1, maSP);
		ResultSet rs = ps.executeQuery();
		Shipper sp = new Shipper();
		while (rs.next()) {
			sp = new Shipper();
			String tenShipper = rs.getString("tenShipper");
			System.out.println(tenShipper);

		}

	}
/**
 * Hien thi thong tin cac don hang da nhan nhung chua giao
 * @param maSP
 * @param con
 * @return
 * @throws SQLException
 */
	public boolean thongtin(String maSP, Connection con) throws SQLException {
		String sql = "SElECT maDH, tenNguoiNhan, diaChi, tenMonHang, sdt FROM DON_HANG WHERE maShipper = ? AND trangThaiGiaoHang = 'Chua giao'";
		PreparedStatement ps = con.prepareStatement(sql);
		List<DonHang> list = new ArrayList<>();
		ps.setString(1, maSP);
		ResultSet rs = ps.executeQuery();
		DonHang dh = new DonHang();
		int count = 0;
		while (rs.next()) {
			dh = new DonHang();
			String maDH = rs.getString("maDH");
			String tenNguoiNhan = rs.getString("tenNguoiNhan");
			String diaChi = rs.getString("diaChi");
			String tenMonHang = rs.getString("tenMonHang");
			String sdt = rs.getString("sdt");
			System.out.println("maDH = " + maDH + "  tenNguoiNhan= " + tenNguoiNhan + "  diaChiNguoiNhan= " + diaChi
					+ "  tenMonHang= " + tenMonHang + "  sdt= " + sdt);
			count++;
		}
		if (count == 0) {
			System.out.println("Chua co don nao");
			return true;
		}else {
			return false;
		}

	}
/**
 * Hien thi don hang chua dang ky de dang ky ship
 * @param maSP
 * @param con
 * @return
 * @throws SQLException
 */
	public boolean donhangchuadangky(String maSP, Connection con) throws SQLException {
		String sql = "SElECT maDH, tenNguoiNhan, diaChi, tenMonHang, sdt FROM DON_HANG WHERE maShipper is null AND trangThaiGiaoHang = 'Chua giao'";
		PreparedStatement ps = con.prepareStatement(sql);
		List<DonHang> list = new ArrayList<>();
		
		ResultSet rs = ps.executeQuery();
		DonHang dh = new DonHang();
		int count = 0;
		while (rs.next()) {
			dh = new DonHang();
			String maDH = rs.getString("maDH");
			String tenNguoiNhan = rs.getString("tenNguoiNhan");
			String diaChi = rs.getString("diaChi");
			String tenMonHang = rs.getString("tenMonHang");
			String sdt = rs.getString("sdt");
			System.out.println("maDH = " + maDH + "  tenNguoiNhan= " + tenNguoiNhan + "  diaChiNguoiNhan= " + diaChi
					+ "  tenMonHang= " + tenMonHang + "  sdt= " + sdt);
			count++;
			list2.add(maDH);
		}
		if (count == 0) {

			System.out.println("Chua co don nao de dang ky ");
			return false;
		}else {
			return true;
		}

	}
/**
 * Dang ky ship
 * @param dh
 * @param con
 * @return
 * @throws SQLException
 */
	public DonHang updateDon(DonHang dh, Connection con) throws SQLException {
		Connection conn = ConnectionUtil.getConnection();
		String sql = "UPDATE DON_HANG SET maShipper = ?  WHERE trangThaiPheDuyet = 'Da phe duyet' AND maDH= ? ";
		PreparedStatement ps = con.prepareStatement(sql);
		ps = conn.prepareStatement(sql);
		ps.setString(1, dh.getMaShipper());
		ps.setString(2, dh.getMaDH());
		if (ps.executeUpdate() > 0) {
			System.out.println("Dang ky thanh cong");
		} else {
			System.out.println("Dang ky that bai");
		}
		return dh;
	}

/**
 * Hien thi tien theo thang nhap vao
 * @param maSP
 * @param con
 * @throws SQLException
 */
public void luongnhanvien(String maSP, Connection con)throws SQLException{
String sql = "SELECT  maShipper, sum(thanhTien) as tienLuong FROM DON_HANG dh, CHI_TIET_DON_HANG ctdh\r\n"
		+ "WHERE MONTH(ngayGiaoHang)  = ? AND dh.maDH=ctdh.maDH\r\n" + "AND maShipper = ? GROUP BY maShipper";
     PreparedStatement ps = con.prepareStatement(sql);
       List<DonHang> list = new ArrayList<>();
       DonHang dh = new DonHang();
       int month = Validate.checkThang("Nhap thang can xem luong");
       ps.setInt(1, month);
       
       ps.setString(2, maSP);
       ResultSet rs = ps.executeQuery();
       ChiTietDonHang ctdh = new ChiTietDonHang();
       int count = 0;
	
		while (rs.next()) {
			dh = new DonHang();
			String maShipper = rs.getString("maShipper");
			Double salaryShipper = rs.getDouble("tienLuong") * 0.75;

			System.out.println("Tien luong thang " + month + " cua Shipper " + maShipper + "la: " + salaryShipper+ " VND");
			count++;
		}
		if (count == 0) {
			System.out.println("Chua co luong thang nay ");
		}
}
}


