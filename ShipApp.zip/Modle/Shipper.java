package MJP.MVP.giaohangModel;

import java.sql.Date;

public class Shipper {
	private String maShipper;
	private String tenShipper;
	private String diaChi;
	private Date ngaySinh;
	private String gioiTinh;
	private String sdt;
	private String email;
	private String truong, lop, trangThaiShipper;

	public Shipper(String maShipper, String tenShipper, String diaChi, Date ngaySinh, String gioiTinh, String sdt,
			String email, String truong, String lop, String trangThaiShipper) {
		super();
		this.maShipper = maShipper;
		this.tenShipper = tenShipper;
		this.diaChi = diaChi;
		this.ngaySinh = ngaySinh;
		this.gioiTinh = gioiTinh;
		this.sdt = sdt;
		this.email = email;
		this.truong = truong;
		this.lop = lop;
		this.trangThaiShipper = trangThaiShipper;
	}

	public Shipper() {
		super();
	}

	public String getTruong() {
		return truong;
	}

	public void setTruong(String truong) {
		this.truong = truong;
	}

	public String getLop() {
		return lop;
	}

	public void setLop(String lop) {
		this.lop = lop;
	}

	@Override
	public String toString() {
		return "Shipper [maShipper=" + maShipper + ", tenShipper=" + tenShipper + ", diaChi=" + diaChi + ", ngaySinh="
				+ ngaySinh + ", gioiTinh=" + gioiTinh + ", sdt=" + sdt + ", email=" + email + ", truong=" + truong
				+ ", lop=" + lop + "]";
	}

	public String getTrangThaiShipper() {
		return trangThaiShipper;
	}

	public void setTrangThaiShipper(String trangThaiShipper) {
		this.trangThaiShipper = trangThaiShipper;
	}

	public String getMaShipper() {
		return maShipper;
	}

	public void setMaShipper(String maShipper) {
		this.maShipper = maShipper;
	}

	public String getTenShipper() {
		return tenShipper;
	}

	public void setTenShipper(String tenShipper) {
		this.tenShipper = tenShipper;
	}

	public String getDiaChi() {
		return diaChi;
	}

	public void setDiaChi(String diaChi) {
		this.diaChi = diaChi;
	}

	public Date getNgaySinh() {
		return ngaySinh;
	}

	public void setNgaySinh(java.util.Date ngaySinh2) {
		this.ngaySinh = (Date) ngaySinh2;
	}

	public String getGioiTinh() {
		return gioiTinh;
	}

	public void setGioiTinh(String gioiTinh) {
		this.gioiTinh = gioiTinh;
	}

	public String getSdt() {
		return sdt;
	}

	public void setSdt(String sdt) {
		this.sdt = sdt;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
