package MJP.MVP.giaohangModel;


import java.sql.Date;

public class DonHang {
	public String maKH;
	public String maDH;
	public String maDV;
	public String maLH;
	public String maPT;
	public String maShipper;
	public Date ngayGiaoHang;
	public String diaChi;
	public String tenMonHang;
	public String sdt;
	public String tenNguoiNhan;
	public String trangThaiPheDuyet;
	public String trangThaiGiaoHang;
	public String trangThaiDonHang;
	
	public DonHang() {
		
	}

	public DonHang(String maKH, String maDH, String maDV, String maLH, String maPT, String maShipper,
			Date ngayGiaoHang, String diaChi, String tenMonHang, String sdt, String tenNguoiNhan,
			String trangThaiPheDuyet, String trangThaiGiaoHang, String trangThaiDonHang) {
		super();
		this.maKH = maKH;
		this.maDH = maDH;
		this.maDV = maDV;
		this.maLH = maLH;
		this.maPT = maPT;
		this.maShipper = maShipper;
		this.ngayGiaoHang = ngayGiaoHang;
		this.diaChi = diaChi;
		this.tenMonHang = tenMonHang;
		this.sdt = sdt;
		this.tenNguoiNhan = tenNguoiNhan;
		this.trangThaiPheDuyet = trangThaiPheDuyet;
		this.trangThaiGiaoHang = trangThaiGiaoHang;
		this.trangThaiDonHang = trangThaiDonHang;
	}

	public String getMaKH() {
		return maKH;
	}

	public void setMaKH(String maKH) {
		this.maKH = maKH;
	}

	public String getMaDH() {
		return maDH;
	}

	public void setMaDH(String maDH) {
		this.maDH = maDH;
	}

	public String getMaDV() {
		return maDV;
	}

	public void setMaDV(String maDV) {
		this.maDV = maDV;
	}

	public String getMaLH() {
		return maLH;
	}

	public void setMaLH(String maLH) {
		this.maLH = maLH;
	}

	public String getMaPT() {
		return maPT;
	}

	public void setMaPT(String maPT) {
		this.maPT = maPT;
	}

	public String getMaShipper() {
		return maShipper;
	}

	public void setMaShipper(String maShipper) {
		this.maShipper = maShipper;
	}

	public Date getNgayGiaoHang() {
		return ngayGiaoHang;
	}

	public void setNgayGiaoHang(Date ngayGiaoHang) {
		this.ngayGiaoHang = ngayGiaoHang;
	}

	public String getDiaChi() {
		return diaChi;
	}

	public void setDiaChi(String diaChi) {
		this.diaChi = diaChi;
	}

	public String getTenMonHang() {
		return tenMonHang;
	}

	public void setTenMonHang(String tenMonHang) {
		this.tenMonHang = tenMonHang;
	}

	public String getSdt() {
		return sdt;
	}

	public void setSdt(String sdt) {
		this.sdt = sdt;
	}

	public String getTenNguoiNhan() {
		return tenNguoiNhan;
	}

	public void setTenNguoiNhan(String tenNguoiNhan) {
		this.tenNguoiNhan = tenNguoiNhan;
	}

	public String getTrangThaiPheDuyet() {
		return trangThaiPheDuyet;
	}

	public void setTrangThaiPheDuyet(String trangThaiPheDuyet) {
		this.trangThaiPheDuyet = trangThaiPheDuyet;
	}

	public String getTrangThaiGiaoHang() {
		return trangThaiGiaoHang;
	}

	public void setTrangThaiGiaoHang(String trangThaiGiaoHang) {
		this.trangThaiGiaoHang = trangThaiGiaoHang;
	}

	public String getTrangThaiDonHang() {
		return trangThaiDonHang;
	}

	public void setTrangThaiDonHang(String trangThaiDonHang) {
		this.trangThaiDonHang = trangThaiDonHang;
	}

	@Override
	public String toString() {
		return "DON_HANG [maKH=" + maKH + ", maDH=" + maDH + ", maDV=" + maDV + ", maLH=" + maLH + ", maPT=" + maPT
				+ ", maShipper=" + maShipper + ", ngayGiaoHang=" + ngayGiaoHang + ", diaChi=" + diaChi + ", tenMonHang="
				+ tenMonHang + ", sdt=" + sdt + ", tenNguoiNhan=" + tenNguoiNhan + ", trangThaiPheDuyet="
				+ trangThaiPheDuyet + ", trangThaiGiaoHang=" + trangThaiGiaoHang + ", trangThaiDonHang="
				+ trangThaiDonHang + "]";
	}
	
	
	
}

