package MJP.MVP.giaohangModel;

import java.sql.Date;

public class admin {
 
	private String maShipper;
	private int count;

	public admin() {
		
	}

	public admin(String maShipper, int count) {
		super();
		this.maShipper = maShipper;
		this.count = count;
	}

	public String getMaShipper() {
		return maShipper;
	}

	public void setMaShipper(String maShipper) {
		this.maShipper = maShipper;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	@Override
	public String toString() {
		return "admin [maShipper=" + maShipper + ", count=" + count + "]";
	}
	
	
	
}
