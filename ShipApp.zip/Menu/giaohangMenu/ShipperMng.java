package MJP.MVP.giaohangMenu;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import MJP.MVP.giaohang.ConnectionUtil;
import MJP.MVP.giaohangModel.ChiTietDonHang;
import MJP.MVP.giaohangModel.DonHang;
import MJP.MVP.giaohangModel.Shipper;
import MJP.MVP.giaohangModel.ShipperDAO;

public class ShipperMng {
	static Connection con = null;
	static Validate Validate= new Validate();

	public static void main(String[] args) throws SQLException {
		Connection conn = ConnectionUtil.getConnection();
		try {
			try {
				chucnangShipper();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} finally {
			conn.close();
		}
	}

	public static void chucnangShipper() throws SQLException {
		try {
			List<DonHang> list = new ArrayList<>();
			Scanner scanner = new Scanner(System.in);
			//MJP.MVP.giaohangModel.Shipper spdao = new MJP.MVP.giaohangModel.Shipper();
			//MJP.MVP.giaohangModel.Shipper sp = new MJP.MVP.giaohangModel.Shipper();
			Shipper  sp= new Shipper();
			ShipperDAO spdao = new ShipperDAO();
			DonHang dh = new DonHang();
			ChiTietDonHang ctdh = new ChiTietDonHang();
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
			boolean check = true, check3 = true, check4 = true, check5 = true;

			while (check3 == true) {
				System.out.println("=========MENU SHIPPER========");
				System.out.println("1. Dang nhap\n2. Dang ky\n3. Thoat");
				int chondi = Integer.parseInt(scanner.nextLine());
				switch (chondi) {
				case 1:
					System.out.println("Moi nhap ID Shipper");
					String ID = scanner.nextLine();

					if (spdao.checkExitShipper(ID, con) == true) {
						check3 = false;
					
						while (check == true) {
							System.out.println("=========MENU=========");
							System.out.print("Xin chao ");
							spdao.tenShipper(ID, con);
							System.out.println("1. Dang ky nhan don hang\n2. Cap nhat trang thai don hang"
									+ "\n3. Liet ke so lan da giao don\n4. Tim kiem thong tin don hang chua giao\n5. Liet ke so don hang da huy\n6. Xem tien cong theo thang\n7. Dang xuat");
							int phim = Validate.checkInt("");
							switch (phim) {
							case 1:
								if(!spdao.donhangchuadangky(ID, con)) {
									System.out.println("===========================");
									break;
								}
								System.out.println("Ban co muon dang ky khong?\n1. Co \n2. Khong");
								int luachon = Integer.parseInt(scanner.nextLine());
								System.out.println("===============================");
								switch (luachon) {
								case 1:

									boolean loop = true;
									while (loop) {
										String maDH = Validate.checkMaDH("Nhap ma don hang muon dang ky!");
										dh.setMaDH(maDH);
										if (spdao.list2.contains(dh.getMaDH())) {
											dh.setMaShipper(ID);
											spdao.updateDon(dh, con);

											System.out.println("===============================");
											loop = false;

										}
									}
									break;

								default:
									break;
								}
								break;
							case 2:
								if(spdao.thongtin(ID, con)) {
									System.out.println("===========================");
									break;
								}
								
							
								String maDH = Validate.checkMaDH("Nhap ma don hang");
								dh.setMaDH(maDH);
								String trangthai = Validate.checkString("Nhap trang thai");
								dh.setTrangThaiGiaoHang(trangthai);
								dh.setMaShipper(ID);
								spdao.updateTrangThaiGH(dh, con);
								System.out.println("===================================");
								break;
								
							case 3:
								spdao.solanGH(ID, con);
								System.out.println("===================================");
								break;
							case 4:
								spdao.thongtin(ID, con);
								System.out.println("===================================");
								break;
							case 5:
								spdao.solanhuydon(ID, con);
								System.out.println("===================================");
								break;
							case 6:
								spdao.luongnhanvien(ID, con);
								break;
						    case 7:
								check = false;
								System.out.println("Da dang xuat tai khoan");
								chucnangShipper();
								return;
							default:
								System.out.println("Moi nhap lai");
								break;
							}
						
						}
					} else {
						System.out.println("ID khong ton tai");
						System.out.println("=====================");
					}
				case 2:
					//sp = new Shipper();
					sp=new MJP.MVP.giaohangModel.Shipper();
					String maShipper = Validate.checkMaShipper("Nhap ma Shipper");
					while(Validate.checkExistIDSP(maShipper)) {
						System.out.println("maShipper da ton tai! Vui long nhap lai");
						 maShipper = Validate.checkMaShipper("Nhap ma Shipper");
					}
					sp.setMaShipper(maShipper);
					String tenShipper = Validate.checkString("Nhap ten Shipper");
					sp.setTenShipper(tenShipper);
					String diaChi = Validate.checkString("Nhap dia chi Shipper");
					sp.setDiaChi(diaChi);
					Date ngaySinh = Validate.checkDate("Nhap ngay sinh(yyyy-mm-dd)");
					sp.setNgaySinh(ngaySinh);
					String gioiTinh = Validate.checkGioiTinh("Nhap gioi tinh");
					sp.setGioiTinh(gioiTinh);
					String sdt = Validate.checkSDT("Nhap sdt");
					while(Validate.checkExistsdt(sdt)) {
						System.out.println("So dien thoai nay da dang ky! Vui long nhap so khac");
						sdt = Validate.checkSDT("Nhap sdt");
					}
					sp.setSdt(sdt);
					String email = Validate.checkEmail("Nhap email");
					sp.setEmail(email);
					String truong = Validate.checkString("Nhap truong");
					sp.setTruong(truong);
					String lop = Validate.checkString("Nhap lop");
					sp.setLop(lop);
					spdao.insertShipper(sp, con);
					break;
				default:
					System.out.println("Da thoat chuong trinh");
					check3 = false;
					break;
					}
			}
		}
//		System.out.println("Moi nhap ID Shipper");
//		ID = scanner.nextLine();

		catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (con != null)
				try {
					con.close();
				} catch (SQLException se) {
					se.printStackTrace();
				}
		}
	}
}
