package MJP.MVP.giaohangMenu;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import Final_Test.ConnectionUtil;
import MJP.MVP.giaohangModel.KhachHang;

public class Validate {

	public static void main(String[] args) {

	}

	// them thong tin khach hang
	public static void insertthongtinKH() {
		// methods de insert khách hàng
		String sql = "INSERT INTO KHACH_HANG Values(?,?,?,?,?,?)";
		Connection conn = ConnectionUtil.getConnection();
		PreparedStatement prstm = null;
		try {
			prstm = conn.prepareStatement(sql);
			// Nhập các thông tin cần insert vào từ bàn phím

			String maKH = Validate.checkMaKH("Nhap vao ma khach hang");
			while (Validate.checkExistKH(maKH)) {
				System.out.println(" Ma khach hang nay da ton tai moi ban dang nhap lai");
				maKH = Validate.checkMaKH("Nhap vao ma khach hang");

			}

			String tenKH = Validate.checkString("Nhap vao ten");
			String diaChi = Validate.checkString("Nhap vao dia chi giao hang");
			Date ngaySinh = Validate.checkBirthDay("Nhap vao ngay sinh ");
			String gioiTinh = Validate.checkGioiTinh("Nhap vao gioi tinh");
			String sdt = Validate.checkSDT("Nhap vao so dien thoai");

			while (Validate.checkExistSDT(sdt)) {
				System.out.println(
						" Khong the tao moi khach hang vi KH nay da bi khoa truoc day, so dien thoai nay da dung roi");
				sdt = Validate.checkSDT("Nhap vao so dien thoai");
			}
			// gán vào cho database
			prstm.setString(1, maKH);
			prstm.setString(2, tenKH);
			prstm.setString(3, diaChi);
			prstm.setDate(4, ngaySinh);
			prstm.setString(5, gioiTinh);
			prstm.setString(6, sdt);
			int numberRecordInsert = prstm.executeUpdate();
			if (numberRecordInsert > 0) {
				System.out.println("Them thanh cong : " + numberRecordInsert + " thong tin khach hang  ");
			} else {
				System.out.println("Them thong tin khong thanh cong ");
			}
		} catch (SQLException e) {

			e.printStackTrace();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

		}
	}

	public static Scanner sc = new Scanner(System.in);

	public static void updateTrangThaiDH1(String maDH) {
		// methods de cap nhat trang thai DH thanh da phe duyet
		Connection conn = ConnectionUtil.getConnection();
		PreparedStatement prstm = null;
		// String maDH = validate.checkString("Vui long nhap nhung ma don hang ban muon
		// cap nhap");
		ArrayList<String> listDH = new ArrayList<String>();
		listDH.add(maDH);
		if (Validate.checkExistID(maDH)) {
			try {
				String sql = "UPDATE DON_HANG SET trangThaiPheDuyet = ? WHERE trangThaiPheDuyet = ? AND maDH= ?";
				prstm = conn.prepareStatement(sql);

				Validate.checkExistID(maDH);
				String updateTrangThaiPD = "Da phe duyet";
				String trangThaiPD = "Chua phe duyet";
				prstm.setString(1, updateTrangThaiPD);
				prstm.setString(2, trangThaiPD);
				prstm.setString(3, maDH);
				int numberRecordUpdate = prstm.executeUpdate();
				if (numberRecordUpdate > 0) {
					System.out.println("Cap nhat thanh cong : " + maDH);
				} else {
					System.out.println("Cap nhat khong thanh cong vi chua co don hang phu hop dieu kien");
				}

			} catch (SQLException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				ConnectionUtil.closeConnection(conn, prstm, null);
			}

		} else {
			System.out.println("Cap nhat khong thanh cong vi ma don hang nay khong ton tai");
		}

	}

	// kiểm tra 1 chuỗi String nhập vào
	public static String checkString(String message) {
		do {
			System.out.println(message);
			String s = sc.nextLine();
			if (s.length() > 50) {
				System.out.println("Vui long nhap duoi 50 ky tu");
				continue;
			}
			if (!s.isEmpty()) {
				return s;
			}
		} while (true);
	}

	// kiểm tra ngày tháng nhập vào đúng format chưa
	public static Date checkDate(String message) {
		do {
			try {
				System.out.println(message);
				LocalDate date = LocalDate.parse(sc.nextLine());
				LocalDate currentDate = LocalDate.now();
				LocalDate minDate = LocalDate.of(1, 1, 1);

				if (date.isAfter(currentDate)) {
					System.out.println("Khong duoc nhap ngay lon hon ngay hien tai");
				} else if (date.isBefore(minDate)) {
					System.out.println("Khong duoc nhap ngay am");
				} else if (date.getMonthValue() == 2 && date.lengthOfMonth() > YearMonth.now().lengthOfMonth()) {
					System.out.println("Thang 2 cua nam hien tai chi co " + YearMonth.now().lengthOfMonth() + " ngay");
				} else {
					return Date.valueOf(date);
				}
			} catch (DateTimeParseException e) {
				System.out.println("Vui long nhap dung format sau YYYY-MM-DD");
			}
		} while (true);
	}

	public static String checkSDT(String message) {
		do {
			System.out.println(message);
			String s = sc.nextLine();
			Pattern check = Pattern.compile("^(03|05|07|08|09)[0-9]{8}$");
			if (check.matcher(s).find() && !s.contains("-") && !s.contains("*") && !s.contains("#") && !s.contains("+")
					&& !s.contains("/") && !s.contains("\\")) {
				return s;
			} else {
				System.out.println(
						"Vui long nhap dung format cua SDT gom 10 chu so , bat dau bang cac dau so 03x, 05x, 07x, 08x, 09x");
			}
		} while (true);
	}

	// check email
	public static String checkEmail(String message) {
		do {
			System.out.println(message);
			String email = sc.nextLine();
			Pattern pattern = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");
			Matcher matcher = pattern.matcher(email);

			if (matcher.matches()) {
				return email;
			} else {
				System.out.println("Email khong hop le, vui long nhap lai!");
			}
		} while (true);
	}

	// check gioi tinh
	public static String checkGioiTinh(String message) {
		do {
			System.out.println(message);
			String gender = sc.nextLine();
			if (gender.equalsIgnoreCase("nam") || gender.equalsIgnoreCase("nu")) {
				return gender;
			} else {
				System.out.println("Giới tính không hợp lệ, vui lòng nhập lại!");
			}
		} while (true);
	}

	public static int checkInt(String message) {
//					
		do {
			System.out.println(message);
			try {
				int n = Integer.parseInt(sc.nextLine());
				return n;
			} catch (Exception e) {
				System.out.println("Vui long nhap lai dung format ");

			}
		} while (true);
	}

	public static int checkThang(String message) {
//		
		do {
			System.out.println(message);
			try {
				int thang = Integer.parseInt(sc.nextLine());
				if (thang >= 1 && thang <= 12) {
					return thang;
				} else {
					System.out.println("Vui long nhap lai tu thang 1 -- thang 12 ");
				}
			} catch (Exception e) {
				System.out.println("Vui long nhap lai thang la so nguyen duong ");
				continue;
			}
		} while (true);
	}

	public static int checkQuy(String message) {
//		
		do {
			System.out.println(message);
			try {
				int quy = Integer.parseInt(sc.nextLine());
				if (quy >= 1 && quy <= 4) {
					return quy;
				} else {
					System.out.println("Vui long nhap lai tu quy 1 -- quy 4 ");
				}
			} catch (Exception e) {
				System.out.println("Vui long nhap lai quy la so nguyen duong ");
				continue;
			}
		} while (true);
	}

	public static int checkSuLuaChon(String message) {
//		
		do {
			System.out.println(message);
			try {
				int suLuaChon = Integer.parseInt(sc.nextLine());
				if (suLuaChon == 1) {
					return suLuaChon;
				} else if (suLuaChon == 2) {
					return suLuaChon;
				} else {
					System.out.println("Vui long nhap lai 1 trong 2 su lua chon ");
				}
			} catch (Exception e) {
				System.out.println("Vui long nhap lai quy la so nguyen duong ");
				continue;
			}
		} while (true);
	}

	public static boolean exit() {
		System.out.println();
		System.out.println("Ban chac chan muon thoat khong?");
		System.out.println("1.Dong y thoat");
		System.out.println("2.Huy bo");
		int choice = checkSuLuaChon("Moi ban chon dung chuc nang minh muon thuc hien ");
		switch (choice) {
		case 1:
			System.out.println("Cam on ban da su dung phan mem");
			return true;
		}
		return false;
	}

	public static int[] getMonthRange(int quy) {
		int monthStart, monthEnd;

		switch (quy) {
		case 1:
			monthStart = 1;
			monthEnd = 3;
			break;
		case 2:
			monthStart = 4;
			monthEnd = 6;
			break;
		case 3:
			monthStart = 7;
			monthEnd = 9;
			break;
		case 4:
			monthStart = 10;
			monthEnd = 12;
			break;
		default:
			monthStart = 0;
			monthEnd = 0;
			break;
		}

		int[] result = { monthStart, monthEnd };
		return result;
	}

	public static boolean checkExistID(String maDH) {
		Connection conn = null;
		PreparedStatement prstm = null;
		ResultSet rs = null;
		do {
			try {
				conn = ConnectionUtil.getConnection();
				String sql = "Select * From DON_HANG where maDH = ?";
				prstm = conn.prepareStatement(sql);

				prstm.setString(1, maDH);
				rs = prstm.executeQuery();
				if (!rs.isBeforeFirst()) {
					return false;
				} else {
					conn.close();
					return true;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				ConnectionUtil.closeConnection(conn, null, rs);
			}
		} while (true);
	}

	public static boolean checkExistKH(String maKH) {
		Connection conn = null;
		PreparedStatement prstm = null;
		ResultSet rs = null;
		do {
			try {
				conn = ConnectionUtil.getConnection();
				String sql = "Select * From KHACH_HANG where maKH = ?";
				prstm = conn.prepareStatement(sql);

				prstm.setString(1, maKH);
				rs = prstm.executeQuery();
				if (!rs.isBeforeFirst()) {
					return false;
				} else {
					conn.close();
					return true;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				ConnectionUtil.closeConnection(conn, null, rs);
			}
		} while (true);
	}

	// metheds de check nam
	public static int checkNam(String message) {
		do {
			System.out.println(message);
			try {
				int nam = Integer.parseInt(sc.nextLine());
				if (nam >= 2015 && nam <= Calendar.getInstance().get(Calendar.YEAR)) {
					return nam;
				} else {
					System.out.println(
							"Cong ty chung toi moi thanh lap. Vui long nhap lai nam trong khoang tu 2015 den nam hien tai");
				}
			} catch (NumberFormatException e) {
				System.out.println("Vui long nhap lai nam la so nguyen duong ");
				continue;
			}
		} while (true);
	}

	public static boolean checkExistIDSP(String maSP) throws SQLException {
		Connection conn = null;
		PreparedStatement prstm = null;
		ResultSet rs = null;
		do {
			try {
				 conn = ConnectionUtil.getConnection();
				String sql = "Select * From SHIPPER where maShipper = ?";
				prstm = conn.prepareStatement(sql);
				prstm.setString(1, maSP);
				rs = prstm.executeQuery();
				if (!rs.isBeforeFirst()) {
					return false;
				} else {
					conn.close();
					return true;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				conn.close();
			}
		} while (true);
	}

	public static boolean checkExistsdt(String sdt) throws SQLException {
		Connection conn = null;
		PreparedStatement prstm = null;
		ResultSet rs = null;
		do {
			try {
				conn = ConnectionUtil.getConnection();
				String sql = "Select * From SHIPPER where sdt = ?";
				prstm = conn.prepareStatement(sql);
				prstm.setString(1, sdt);
				rs = prstm.executeQuery();
				if (!rs.isBeforeFirst()) {
					return false;
				} else {
					conn.close();
					return true;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				conn.close();
			}
		} while (true);
	}

	// methods check ngay sinh nhat
	public static Date checkBirthDay(String message) {
		do {
			try {
				System.out.println(message);
				LocalDate date = LocalDate.parse(sc.nextLine());
				LocalDate currentDate = LocalDate.now();
				LocalDate minDate = LocalDate.of(1, 1, 1);

				if (date.plusYears(18).isAfter(currentDate)) {
					System.out.println("Ngay sinh phai tren 18 tuoi so voi nam hien tai");
				} else if (date.isBefore(minDate)) {
					System.out.println("Khong duoc nhap ngay am");
				} else if (date.getMonthValue() == 2 && date.lengthOfMonth() > YearMonth.now().lengthOfMonth()) {
					System.out.println("Thang 2 cua nam hien tai chi co " + YearMonth.now().lengthOfMonth() + " ngay");
				} else {
					return Date.valueOf(date);
				}
			} catch (DateTimeParseException e) {
				System.out.println("Vui long nhap dung format sau YYYY-MM-DD");
			}
		} while (true);
	}

	// metheds de check sdt cua shipper nhap vao trung database
	public static boolean checkExistSDT(String sdt) {
		Connection conn = null;
		PreparedStatement prstm = null;
		ResultSet rs = null;
		do {
			try {
				conn = ConnectionUtil.getConnection();
				String sql = "Select * From KHACH_HANG where sdt= ? AND trangThaiKH= 'disable'";
				prstm = conn.prepareStatement(sql);

				prstm.setString(1, sdt);
				rs = prstm.executeQuery();
				if (!rs.isBeforeFirst()) {
					return false;
				} else {
					conn.close();
					return true;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				ConnectionUtil.closeConnection(conn, null, rs);
			}
		} while (true);
	}

	public static String checkMaDH(String message) {
		do {
			System.out.println(message);
			String s = sc.nextLine();
			Pattern check = Pattern.compile("^DH[0-9]{5}$");
			if (check.matcher(s).find()) {
				return s;
			} else {
				System.out.println(
						"Vui long nhap dung format cua ma don hang, gom 7 ky tu va bat dau bang : DHxxxxx, voi x la cac so tu 0-9");
			}
		} while (true);
	}

	public static String checkMaKH(String message) {
		do {
			System.out.println(message);
			String s = sc.nextLine();
			Pattern check = Pattern.compile("^KH[0-9]{5}$");
			if (check.matcher(s).find()) {
				return s;
			} else {
				System.out.println(
						"Vui long nhap dung format cua ma khach hang, gom 7 ky tu va bat dau bang : KHxxxxx, voi x la cac so tu 0-9");
			}
		} while (true);
	}

	public static String checkMaShipper(String message) {
		do {
			System.out.println(message);
			String s = sc.nextLine();
			Pattern check = Pattern.compile("^SP[0-9]{5}$");
			if (check.matcher(s).find()) {
				return s;
			} else {
				System.out.println(
						"Vui long nhap dung format cua ma Shipper, gom 7 ky tu va bat dau bang : SPxxxxx, voi x la cac so tu 0-9");
			}
		} while (true);
	}
	public static String checkMaDV(String message) {
		do {
			System.out.println(message);
			String s = sc.nextLine();
			if (s.equals("DV00001") || s.equals("DV00002") || s.equals("DV00003")) {
				return s;
			} else {
				System.out.println(
						"Vui long nhap dung ma dich vu, gom 3 lua chon: DV00001 = Giao nhanh trong ngay, DV00002 = Giao ban dem, DV00003 = Giao cuoi tuan");
			}
		} while (true);
	}

	public static String checkMaLH(String message) {
		do {
			System.out.println(message);
			String s = sc.nextLine();
			if (s.equals("LH00001") || s.equals("LH00002") || s.equals("LH00003")) {
				return s;
			} else {
				System.out.println(
						"Vui long nhap dung ma loai hang, gom 3 lua chon: LH00001 = Hang de vo, LH00002 = Hang de hu hong, LH00003 = Hang hoa thong thuong");
			}
		} while (true);
	}

	public static String checkMaPT(String message) {
		do {
			System.out.println(message);
			String s = sc.nextLine();
			if (s.equals("PT00001") || s.equals("PT00002")) {
				return s;
			} else {
				System.out.println(
						"Vui long nhap dung ma phuong thuc, gom 2 lua chon: PT00001 = Thanh toan bang tien mat, PT00002 = Thanh toan bang chuyen khoan");
			}
		} while (true);
	}
}

