package MJP.MVP.giaohangMenu;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Final_Test.ConnectionUtil;

import MJP.MVP.giaohangModel.DonHang;

public class AdminMngShipper {
	public static Scanner sc = new Scanner(System.in);
	Validate Validate = new Validate();
	/**
	 * Menu chức năng của admin quản lý Shipper
	 */
	public void admin() {
		AdminMngShipper adminMngShipper = new AdminMngShipper();

		int choice;
		do {
			System.out.println();
			System.out.println("Chao mung admin den voi he thong quan ly don hang ");
			System.out.println("_____________________________");
			System.out.println("---------- MENU ADMIN1------");
			System.out.println("1. Xem cac don hang chua duoc phe duyet");
			System.out.println("2. Cap nhat trang thai phe duyet don hang");
			System.out.println("3. Tao them don hang moi theo yeu cau cua khach hang");
			System.out.println("4. Xoa tai khoan Shipper da vi pham quy dinh cua cong ty");
			System.out.println("5. Tinh luong cho Shipper");
			System.out.println("6. Thong ke cac Shipper co luong cao nhat theo thang");
			System.out.println("7. Lam bao cao cac Shipper co nhieu don hang giao thanh cong nhat theo thang");
			System.out.println("8. Thoat.");
			System.out.println("______________________________");
			System.out.print("Moi ban chon chuc nang ");
			try {
				choice = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("Vui lòng nhap lai su lua chon cua ban la so nguyen duong");
				continue;
			}
			switch (choice) {

			case 1:

				viewInfor();
				break;
			case 2:
				if (viewInfor()) {
					updateTrangThaiDH();
				} else {

				}
				break;
			case 3:
				String maDH = Validate.checkMaDH("Nhap vao ma don hang voi format DHxxxxx( x la so tu 1-9)");
				insertDonHang(maDH);
				break;
			case 4:
				deleteShipper();
				break;
			case 5:
				salaryShipper();
				break;
			case 6:
				maxSalaryShipper();
				break;
			case 7:
				topShipper();
				break;
			case 8:
				if (Validate.exit()) {
					return;
				}
				break;
			default:
				System.out.println("Vui lòng chọn lại các chức năng từ 1 tới 7 ");
				break;
			}
		} while (true);
	}
	/**
	 * Menu chức năng của admin quản lý shipper để xem những đơn hàng chưa đc phê duyệt
	 */
	public boolean viewInfor() {
		// xem thong tin cac don hang chua phe duyet
		Connection conn = ConnectionUtil.getConnection();
		Statement stm = null;
		try {

			String sql = "SELECT * FROM DON_HANG  WHERE trangThaiPheDuyet = 'Chua phe duyet';";
			stm = conn.createStatement();
			ResultSet rs = stm.executeQuery(sql);
			if (rs.isBeforeFirst()) {
				System.out.println("Danh sach cac don hang chua phe duyet la: ");
				ArrayList<DonHang> ListDonHang = new ArrayList<>();
				DonHang donHang = new DonHang();
				while (rs.next()) {
					donHang = new DonHang();
					donHang.setMaDH(rs.getString("maDH"));
					donHang.setMaKH(rs.getString("maKH"));
					donHang.setDiaChi(rs.getString("diaChi"));
					donHang.setTenMonHang(rs.getString("tenMonHang"));
					donHang.setSdt(rs.getString("sdt"));
					donHang.setTenNguoiNhan(rs.getString("tenNguoiNhan"));
					donHang.setTrangThaiPheDuyet(rs.getString("trangThaiPheDuyet"));
					donHang.setTrangThaiGiaoHang(rs.getString("trangThaiGiaoHang"));
					donHang.setTrangThaiDonHang(rs.getString("trangThaiDonHang"));
					donHang.setMaShipper(rs.getString("maShipper"));
					donHang.setMaDV(rs.getString("maDV"));
					donHang.setMaLH(rs.getString("maLH"));
					donHang.setMaPT(rs.getString("maPT"));
					donHang.setNgayGiaoHang(rs.getDate("ngayGiaoHang"));
					ListDonHang.add(donHang);

				}
				for (DonHang donHang2 : ListDonHang) {
					System.out.println(donHang2.toString());
				}
				return true;
			} else {
				System.out.println("Chua co don hang nao can phe duyet");
			}

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			ConnectionUtil.closeConnection(conn, null, null);
		}
		return false;

	}
	/**
	 * Method xem và phê duyệt những đơn hàng chưa đc phê duyệt
	 */
	public void updateTrangThaiDH() {
		// methods de cap nhat trang thai DH thanh da phe duyet
		int soDon = Validate.checkInt("Nhap vao so don hang ban muon phe duyet");
		ArrayList<String> listDH = new ArrayList<String>();
		for (int i = 0; i < soDon; i++) {
			String maDH = Validate.checkMaDH("Vui long nhap ma don hang ban muon cap nhap");
			listDH.add(maDH);
		}
		for (String maDH : listDH) {
			Validate.updateTrangThaiDH1(maDH);
		}
	}
	/**
	 * Method để tạo đơn hàng mới khi khách hàng gọi tổng đài yêu cầu tạo
	 */
	public void insertDonHang(String maDH) {
		// methods de insert don hang mới theo yêu cầu của khách hàng
		String sql = "INSERT INTO DON_HANG Values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		Connection conn = ConnectionUtil.getConnection();
		PreparedStatement prstm = null;
		try {
			prstm = conn.prepareStatement(sql);
			// Nhập các thông tin cần insert vào từ bàn phím

			while (Validate.checkExistID(maDH)) {
				System.out.println("Ma don hang nay da ton tai, vui long nhap lai ma DH moi");
				maDH = Validate.checkMaDH("Nhap vao ma don hang voi format DHxxxxx( x la so tu 1-9)");
			}
			String maKH = Validate.checkMaKH("Nhap vao ma khach hang voi format KHxxxxx( x la so tu 1-9)");
			while (Validate.checkExistKH(maKH) == false) {
				System.out.println("Ma khach hang nay chua ton tai, vui long nhap lai ma KH moi");
				maKH = Validate.checkMaKH("Nhap vao ma khach hang voi format KHxxxxx( x la so tu 1-9)");
			}

			String diaChiGH = Validate.checkString("Nhap vao dia chi giao hang");
			String tenMonHang = Validate.checkString("Nhap vao ten mon hang");

			String sdt = Validate.checkSDT("Nhap vao so dien thoai ng nhan");
			String tenNguoiNhan = Validate.checkString("Nhap vao ten ng nhan");

			String trangThaiPheDuyet = "Chua phe duyet";
			String trangThaiGiaoHang = "Chua giao";
			String trangThaiDonHang = "Chua nhan";
			//
			String maShipper = "NULL";
			String maDV = Validate.checkMaDV("Nhap vao ma dich vu");
			String maLH = Validate.checkMaLH("Nhap vao ma loai hang");
			String maPT = Validate.checkMaPT("Nhap vao ma phuong thuc thanh toan");
			Date ngayGiaoHang = Validate.checkDate("Nhap vao ngay giao hang");
			// gán vào cho database
			prstm.setString(1, maDH);
			prstm.setString(2, maKH);
			prstm.setString(3, diaChiGH);
			prstm.setString(4, tenMonHang);
			prstm.setString(5, sdt);
			prstm.setString(6, tenNguoiNhan);
			prstm.setString(7, trangThaiPheDuyet);
			prstm.setString(8, trangThaiGiaoHang);

			prstm.setString(9, trangThaiDonHang);
			prstm.setString(10, maShipper);
			prstm.setString(11, maDV);
			prstm.setString(12, maLH);
			prstm.setString(13, maPT);
			prstm.setDate(14, ngayGiaoHang);
			int numberRecordInsert = prstm.executeUpdate();
			if (numberRecordInsert > 0) {
				System.out.println("Them thanh cong : " + numberRecordInsert + " don hang ");
			} else {
				System.out.println("Them don hang khong thanh cong");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConnectionUtil.closeConnection(conn, prstm, null);
		}
	}

	static ArrayList<lib.admin> List = new ArrayList<>();
	/**
	 * methods dùng để xóa các shipper vi phạm quy định ( cancel quá 50 đơn/3 tháng_quý)
	 */

	public void deleteShipper() {
		String sql = "SELECT maShipper,COUNT (maShipper) AS Solan FROM DON_HANG WHERE trangThaiGiaoHang = ?  AND YEAR(ngayGiaoHang)= 2023 AND MONTH(ngayGiaoHang) BETWEEN ? AND ?  GROUP BY maShipper ";
		Connection conn = ConnectionUtil.getConnection();
		PreparedStatement prstm = null;
      // neu shipper do bi khoa thì  sau k dc tao moi lai dc ( bằng cách check số đt trùng)
		try {
			prstm = conn.prepareStatement(sql);
			int quy = Validate
					.checkQuy("Nhap vao quy cua nam 2023 ma ban muon tim cac Shipper vi pham quy dinh (1,2,3,4)");

			int monthStart = Validate.getMonthRange(quy)[0];
			int monthEnd = Validate.getMonthRange(quy)[1];
			String trangThaiGH = "Cancel";
			prstm.setString(1, trangThaiGH);
			prstm.setInt(2, monthStart);
			prstm.setInt(3, monthEnd);
			ResultSet rs = prstm.executeQuery();
			if (rs.isBeforeFirst()) {
				// Tạo arraylist để khi cần dùng có

				List<lib.admin> adminMng = new ArrayList<>();
				while (rs.next()) {
					lib.admin admin = new lib.admin(rs.getString("maShipper"), rs.getInt("Solan"));
					adminMng.add(admin);
				}

				ConnectionUtil.closeConnection(null, null, rs);
				for (lib.admin admin : adminMng) {
					if (admin.getCount() >= 1) {
						String sql1 = "UPDATE SHIPPER SET trangThaiShipper = ? WHERE maShipper = ? AND trangThaiShipper= 'Dang hoat dong' ";

						try {
							prstm = conn.prepareStatement(sql1);
							String trangThai = "Da bi khoa";
							prstm.setString(1, trangThai);
							prstm.setString(2, admin.getMaShipper());
							int numberRecordDelete = prstm.executeUpdate();
							if (numberRecordDelete > 0) {
								System.out.println("Xoa thanh cong : " + numberRecordDelete + " shipper la  "
										+ admin.getMaShipper());
							} else {
								System.out.println("Xoa khong thanh cong vi Shipper " + admin.getMaShipper()
										+ " da bi khoa tai khoan truoc do, gio tai khoan nay khong con hoat dong nua");
							}
						} catch (SQLException e) {
							e.printStackTrace();
						} catch (Exception e) {
							e.printStackTrace();
						}
					} else {
						System.out.println("Khong co Shipper nao phu hop dieu kien");
					}

				}
			} else {
				System.out.println("Khong co Shipper nao phu hop dieu kien");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConnectionUtil.closeConnection(conn, prstm, null);
		}
	}
	/**
	 * methods dùng để tinh luong shipper theo tháng
	 */
	public void salaryShipper() {
		// methods de tinh luong shipper

		String sql = "SELECT  maShipper, sum(thanhTien) as tienLuong FROM DON_HANG dh, CHI_TIET_DON_HANG ctdh\r\n"
				+ "WHERE MONTH(ngayGiaoHang)  = ? AND YEAR(ngayGiaoHang)= 2023 AND dh.maDH=ctdh.maDH\r\n"
				+ "group by maShipper ";
		Connection conn = ConnectionUtil.getConnection();
		PreparedStatement prstm = null;
		try {

			prstm = conn.prepareStatement(sql);
			int month = Validate.checkThang("Nhap vao thang ban muon tinh tien luong cho shipper (T1-T12) ");
			prstm.setInt(1, month);
			ResultSet rs = prstm.executeQuery();
			if (rs.isBeforeFirst()) {
				lib.admin salary = new lib.admin();
				while (rs.next()) {
					salary = new lib.admin();
					String maShipper = rs.getString("maShipper");
					Double salaryShipper = rs.getDouble("tienLuong") * 0.75;

					System.out.println("Tien luong thang " + month + " cua Shipper " + maShipper + " la: "
							+ salaryShipper + " VND");

				}
			} else {
				System.out.println("Luong cua shipper hien tai chua co");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConnectionUtil.closeConnection(conn, prstm, null);
		}

	}
	/**
	 * methods dùng để lấy top 3 shipper có lương cao nhất tháng, cuối năm sẽ được tặng thưởng
	 */
	public void maxSalaryShipper() {
		
		String sql = "SELECT TOP 3 maShipper, sum(thanhTien) as tienLuong \r\n"
				+ "FROM DON_HANG dh, CHI_TIET_DON_HANG ctdh \r\n"
				+ "WHERE MONTH(ngayGiaoHang) = ? AND YEAR(ngayGiaoHang)= 2023 AND dh.maDH=ctdh.maDH \r\n"
				+ "GROUP BY maShipper \r\n" + "ORDER BY tienLuong DESC ";
		Connection conn = ConnectionUtil.getConnection();
		PreparedStatement prstm = null;
		try {
			prstm = conn.prepareStatement(sql);
			int month = Validate
					.checkThang("Nhap vao thang ban muon thong ke nhung Shipper co tien luong cao nhat(T1-T12)");
			prstm.setInt(1, month);
			ResultSet rs = prstm.executeQuery();
			if (rs.isBeforeFirst()) {
				System.out.println("Top 3 Shipper co tien luong cao nhat thang " + month + " la: ");
				while (rs.next()) {

					String maShipper = rs.getString("maShipper");
					Double salaryShipper = rs.getDouble("tienLuong") * 0.75;
					System.out.println("Ma Shipper " + maShipper + " tien luong la: " + salaryShipper + " VND");
				}
			} else {
				System.out.println("Luong cua cac shipper hien tai chua co");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConnectionUtil.closeConnection(conn, prstm, null);
		}

	}
	/**
	 * methods dùng để báo cáo top 3 shipper có nhiều đơn hàng giao thành công nhất trong, cuối năm sẽ được tặng thưởng
	 */
	public void topShipper() {
		
		String sql = "SELECT TOP 3 maShipper,count(maShipper)as Solan FROM DON_HANG dh\r\n"
				+ "WHERE trangThaiGiaoHang= 'Da giao hang' AND YEAR(ngayGiaoHang)= 2023 AND MONTH(ngayGiaoHang) = ?\r\n"
				+ "Group by maShipper\r\n" + "ORDER BY Solan DESC";
		Connection conn = ConnectionUtil.getConnection();
		PreparedStatement prstm = null;
		try {
			prstm = conn.prepareStatement(sql);
			int month = Validate.checkThang(
					"Nhap vao thang ban muon lam bao cao top 3 shipper co nhieu don hang giao thanh cong nhat (T1-T12) ");
			prstm.setInt(1, month);
			ResultSet rs = prstm.executeQuery();
			if (rs.isBeforeFirst()) {
				System.out.println("Top 3 Shipper co so don hang giao thanh cong nhieu nhat thang " + month + " la: ");
				while (rs.next()) {
					String maShipper = rs.getString("maShipper");
					int lanGiaoThanhCong = rs.getInt("Solan");
					System.out.println("Ma Shipper  " + maShipper + " giao thanh cong: " + lanGiaoThanhCong + " lan");

				}
			} else {
				System.out.println("Luong cua cac shipper hien tai chua co");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConnectionUtil.closeConnection(conn, prstm, null);
		}

	}

}
