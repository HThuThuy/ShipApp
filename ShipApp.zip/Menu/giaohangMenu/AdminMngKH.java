package MJP.MVP.giaohangMenu;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.JOptionPane;

import MJP.MVP.giaohang.ConnectionUtil;


public class AdminMngKH {
	static Validate Validate= new Validate();
	public static Scanner sc = new Scanner(System.in);
	static String checkSqlInfoKH = "SELECT * FROM KHACH_HANG WHERE maKH = ?";
	static String sqlCheckSdt = "SELECT COUNT(*) AS count FROM KHACH_HANG WHERE sdt = ? AND maKH != ? AND trangThaiKH = 'disable'";
	static String insertSqlInfoKH = "INSERT INTO KHACH_HANG Values(?,?,?,?,?,?,?)";
	static String editSqlInfoKH = "SELECT * FROM KHACH_HANG WHERE maKH = ?";
	static String viewSqlInfoKH = "SELECT KHACH_HANG.maKH, KHACH_HANG.tenKH, KHACH_HANG.diaChi, KHACH_HANG.ngaySinh, KHACH_HANG.gioiTinh, KHACH_HANG.sdt AS sdtKhachHang, DON_HANG.diaChi AS diaChiNhanHang, DON_HANG.tenMonHang, DON_HANG.tenNguoiNhan "
			+ "FROM KHACH_HANG " + "JOIN DON_HANG ON KHACH_HANG.maKH = DON_HANG.maKH " + "WHERE KHACH_HANG.maKH = ?";
	static String deleteSqlKH = "SELECT maKH, COUNT(maKH) AS Solan FROM DON_HANG WHERE trangThaiDonHang = ? AND MONTH(ngayGiaoHang) = MONTH(GETDATE()) GROUP BY maKH";
	static String calSqlBillKH = "SELECT dh.maKH, SUM(ctdh.thanhTien) AS tienHang FROM DON_HANG dh JOIN CHI_TIET_DON_HANG ctdh ON dh.maDH = ctdh.maDH WHERE YEAR(dh.ngayGiaoHang) =? AND MONTH(dh.ngayGiaoHang) = ? GROUP BY dh.maKH";
	static String listSqlTopKH = "SELECT TOP 1 kh.TenKH, SUM(ct.SoLuong * ct.DonGia * ct.TrongLuong) AS TongTien "
			+ "FROM DON_HANG dh " + "INNER JOIN CHI_TIET_DON_HANG ct ON dh.MaDH = ct.MaDH "
			+ "JOIN KHACH_HANG kh ON dh.MaKH = kh.MaKH "
			+ "WHERE YEAR(dh.ngayGiaoHang) =? AND MONTH(dh.NgayGiaoHang) = ? " + "GROUP BY kh.TenKH "
			+ "ORDER BY TongTien DESC";
	static String updateSqlThanhTien = "UPDATE CHI_TIET_DON_HANG " + "SET thanhTien = " + "CASE "
			+ "WHEN trongLuong < 1 AND soLuong = 1 THEN 20000 " + "WHEN trongLuong >= 5 THEN 20000*1.3*trongLuong "
			+ "ELSE 20000*" + "(CASE WHEN trongLuong < 1 THEN (CASE WHEN soLuong < 5 THEN 1.2 ELSE 1.3 END) "
			+ "ELSE (CASE WHEN soLuong < 5 THEN 1.2*trongLuong ELSE 1.3*trongLuong END) END)" + "*soLuong " + "END";
	static String selectSqlKHDisable = "SELECT * FROM KHACH_HANG WHERE trangThaiKH = 'disable'";

	/**
	 * Menu chức năng của admin quản lý khách hàng
	 */
	public static void adminMenu2() {
		int choice;
		do {
			System.out.println();
			System.out.println("----------MENU----------");
			System.out.println("1. Them thong tin khach hang");
			System.out.println("2. Sua thong tin khach hang");
			System.out.println("3. Xem thong tin tai khoan, lich su don hang cua khach hang");
			System.out.println("4. Xoa tai khoan khach hang vi pham");
			System.out.println("5. Cap nhat thanh tien cua toan bo don hang trong DB");
			System.out.println("6. Tinh tien can thu cua khach hang trong thang");
			System.out.println("7. Thong ke khach hang tien hang tra nhieu nhat trong thang");
			System.out.println("8. Quay lai menu chinh");
			System.out.println("______________________________");
			System.out.print("Moi ban chon chuc nang: ");
			try {
				choice = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("Vui long nhap lai su lua chon cua ban tu 1 den 8");
				continue;
			}
			switch (choice) {
			case 1:
				themThongTinKH();
				break;
			case 2:
				suaThongTinKH();
				break;
			case 3:
				xemThongTinKH();
				break;
			case 4:
				xoaKH();
				break;
			case 5:
				updateThanhTienHD();
				break;
			case 6:
				tinhTienKH();
				break;
			case 7:
				top1KH();
				break;
			case 8:
				System.out.println("Cam on ban da su dung he thong!");
				return;
			default:
				System.out.println("Vui long chon lai!");
				break;
			}
		} while (true);
	}

	/**
	 * Thêm thông tin khách hàng nếu khách hàng yêu cầu
	 */
	public static void themThongTinKH() {
		Connection conn = ConnectionUtil.getConnection();
		PreparedStatement prstmCheckmaKH = null;
		PreparedStatement prstmCheckSDT = null;
		PreparedStatement prstmInsert = null;

		try {
			prstmCheckmaKH = conn.prepareStatement(checkSqlInfoKH);
			String maKH = Validate.checkMaKH(
					"Nhap vao Ma khach hang, gom 7 ky tu va bat dau bang : KHxxxxx, voi x la cac so tu 0-9: ");
			prstmCheckmaKH.setString(1, maKH);
			ResultSet rs = prstmCheckmaKH.executeQuery();
			if (rs.next()) {
				System.out.println("Ma khach hang da ton tai trong he thong, vui long nhap lai Ma khach hang khac!");
				return;
			}

			prstmCheckSDT = conn.prepareStatement(sqlCheckSdt);
			String sdt;
			ResultSet rsCheckSDT;
			do {
				sdt = Validate.checkSDT("Nhap vao So dien thoai khach hang: ");
				prstmCheckSDT.setString(1, sdt);
				prstmCheckSDT.setString(2, maKH);
				rsCheckSDT = prstmCheckSDT.executeQuery();
				if (rsCheckSDT.next() && rsCheckSDT.getInt("count") > 0) {
					System.out.println("So dien thoai khong hop le vi khach hang dung sdt do da bi khoa.");
					System.out.println("Vui long nhap lai sdt khac!");
				}
			} while (rsCheckSDT.getInt("count") > 0);

			prstmInsert = conn.prepareStatement(insertSqlInfoKH);
			System.out.println("So dien thoai hop le, vui long nhap tiep cac thong tin sau:");
			String tenKH = Validate.checkString("Nhap vao Ten khach hang: ");
			String diaChiKH = Validate.checkString("Nhap vao Dia chi khach hang: ");
			Date ngaySinh = Validate.checkBirthDay("Nhap vao Ngay sinh khach hang: ");
			String gioiTinh = Validate.checkString("Nhap vao Gioi tinh khach hang: ");
			String trangThaiKH = "active";

			prstmInsert.setString(1, maKH);
			prstmInsert.setString(2, tenKH);
			prstmInsert.setString(3, diaChiKH);
			prstmInsert.setDate(4, ngaySinh);
			prstmInsert.setString(5, gioiTinh);
			prstmInsert.setString(6, sdt);
			prstmInsert.setString(7, trangThaiKH);

			int numberRecordInsert = prstmInsert.executeUpdate();
			if (numberRecordInsert > 0) {
				System.out.println("Them thanh cong : " + numberRecordInsert + " khach hang ");
			} else {
				System.out.println("Them khach hang khong thanh cong!");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// Close all prepared statements and connection
			ConnectionUtil.closeConnection(conn, prstmCheckmaKH, null);
			ConnectionUtil.closeConnection(null, prstmCheckSDT, null);
			ConnectionUtil.closeConnection(null, prstmInsert, null);
		}
	}

	/**
	 * Sửa thông tin khách hàng nếu khách hàng yêu cầu
	 */
	public static void suaThongTinKH() {
		String maKH = Validate
				.checkMaKH("Nhap vao Ma khach hang, gom 7 ky tu va bat dau bang : KHxxxxx, voi x la cac so tu 0-9: ");

		Connection conn = ConnectionUtil.getConnection();
		PreparedStatement checkMaKH = null;
		ResultSet rs = null;
		try {
			checkMaKH = conn.prepareStatement(editSqlInfoKH);
			checkMaKH.setString(1, maKH);
			rs = checkMaKH.executeQuery();
			if (!rs.isBeforeFirst()) {
				System.out.println("Ma khach hang khong ton tai trong he thong.");
				suaThongTinKH(); // Quay lại nhập mã khách hàng để tiếp tục
				return;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return;
		} finally {
			ConnectionUtil.closeConnection(null, checkMaKH, rs);
		}

		String tenKH = Validate.checkString("Nhap vao Ten khach hang can update: ");
		String diaChiKH = Validate.checkString("Nhap vao Dia chi khach hang can update: ");
		String sdt = Validate.checkSDT("Nhap vao So dien thoai khach hang can update: ");

		PreparedStatement prstm = null;
		try {
			String sql = "UPDATE KHACH_HANG SET tenKH = ?, diaChi = ?, sdt = ? WHERE maKH = ?";
			prstm = conn.prepareStatement(sql);
			prstm.setString(1, tenKH);
			prstm.setString(2, diaChiKH);
			prstm.setString(3, sdt);
			prstm.setString(4, maKH);
			int numberRecordUpdate = prstm.executeUpdate();
			if (numberRecordUpdate > 0) {
				System.out.println("Cap nhat thanh cong : " + numberRecordUpdate + " khach hang ");
			} else {
				System.out.println("Cap nhat khong thanh cong!");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConnectionUtil.closeConnection(conn, prstm, null);
		}
	}

	/**
	 * Xem thông tin khách hàng
	 */
	public static void xemThongTinKH() {
		Connection conn = ConnectionUtil.getConnection();
		PreparedStatement ps = null;

		try {
			// Tạo câu truy vấn SQL để lấy thông tin của khách hàng

			ps = conn.prepareStatement(viewSqlInfoKH);

			// Nhập mã khách hàng cần xem thông tin từ bàn phím
			String maKH = Validate
					.checkMaKH("Nhap vao Ma khach hang gom 7 ky tu va bat dau bang: KHxxxxx, voi x la cac so tu 0-9");
			ps.setString(1, maKH);

			// Thực thi câu truy vấn và lấy kết quả trả về
			ResultSet rs = ps.executeQuery();

			if (rs.isBeforeFirst()) { // Nếu có kết quả trả về
				System.out.println("Thong tin khach hang co ma " + maKH + " can tim kiem la: ");
				while (rs.next()) {
					// In ra thông tin của khách hàng và đơn hàng của khách hàng đó
					System.out.println("Ma khach hang: " + rs.getString("maKH"));
					System.out.println("Ho ten: " + rs.getString("tenKH"));
					System.out.println("Dia chi: " + rs.getString("diaChi"));
					System.out.println("Ngay sinh: " + rs.getDate("ngaySinh"));
					System.out.println("Gioi tinh: " + rs.getString("gioiTinh"));
					System.out.println("So dien thoai nguoi dat: " + rs.getString("sdtKhachHang"));
					System.out.println("Dia chi nguoi nhan: " + rs.getString("diaChiNhanHang"));
					System.out.println("Ten mon hang: " + rs.getString("tenMonHang"));
					System.out.println("Ten nguoi nhan: " + rs.getString("tenNguoiNhan"));
					System.out.println("----------------------------------");
				}
			} else { // Nếu không có kết quả trả về
				System.out.println("Khong tim thay khach hang co ma la " + maKH);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConnectionUtil.closeConnection(conn, ps, null); // Đóng kết nối đến cơ sở dữ liệu
		}
	}

	/**
	 * Xóa các KH vi phạm quy định ( Hủy quá 10 đơn/1 tháng gần nhất) Không xóa vật
	 * lý mà thay đổi trạng thái khách hàng thành "disable"
	 */

	public static void xoaKH() {
		Connection conn = ConnectionUtil.getConnection();
		PreparedStatement prstm = null;

		try {
			prstm = conn.prepareStatement(deleteSqlKH);
			String trangThaiDH = "Da xoa";
			prstm.setString(1, trangThaiDH);
			ResultSet rs = prstm.executeQuery();
			if (rs.isBeforeFirst()) {
				List<String> listToDelete = new ArrayList<>();
				while (rs.next()) {
					String maKH = rs.getString("maKH");
					int solan = rs.getInt("Solan");
					if (solan >= 10) {
						listToDelete.add(maKH);
					}
				}
				ConnectionUtil.closeConnection(null, null, rs);
				if (!listToDelete.isEmpty()) {
					String updateSql = "UPDATE KHACH_HANG SET trangThaiKH = ? WHERE maKH = ? ";
					prstm = conn.prepareStatement(updateSql);
					String trangThaiKH = "Disable";
					for (String maKH : listToDelete) {
						prstm.setString(1, trangThaiKH);
						prstm.setString(2, maKH);
						int numberRecordDelete = prstm.executeUpdate();
						if (numberRecordDelete > 0) {
							System.out.println("Xoa thanh cong : " + numberRecordDelete + " khach hang ");
						} else {
							System.out.println("Xoa khong thanh cong");
						}
					}
				} else {
					System.out.println("Khong co khach hang nao bi xoa");
				}
			} else {
				System.out.println("Khong co khach hang nao bi xoa");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConnectionUtil.closeConnection(conn, prstm, null);
		}
	}

	/**
	 * tính tiền hàng của KH trong phạm vi thời gian(tháng) tìm kiếm
	 */
	public static void tinhTienKH() {
		Connection conn = ConnectionUtil.getConnection();
		PreparedStatement prstm = null;
		try {
			prstm = conn.prepareStatement(calSqlBillKH);
			int year = Validate.checkNam("Nhap nam can thong ke: ");
			int month = Validate.checkThang("Nhap thang can tinh tien cua khach hang (1-12): ");
			prstm.setInt(1, year);
			prstm.setInt(2, month);
			ResultSet rs = prstm.executeQuery();
			if (rs.isBeforeFirst()) {
				System.out.println("Thong tin tien hang can thu cua khach hang la: ");
				while (rs.next()) {
					System.out.print("Ma khach hang: " + rs.getString("maKH"));
					System.out.println("Tien hang la: " + rs.getDouble("tienHang"));
				}
			} else {
				System.out.println("Tien hang can thu cua Khach hang hien tai chua co");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConnectionUtil.closeConnection(conn, prstm, null);
		}
	}

	/**
	 * Thống kê khách hàng có tiền hàng cao nhất tháng Hiện dialog nhắc nhở tặng cho
	 * khách hàng đó
	 */
	public static void top1KH() {
		Connection conn = null;
		PreparedStatement prstm = null;
		ResultSet rs = null;

		try {
			conn = ConnectionUtil.getConnection();
			int year = Validate.checkNam("Nhap nam can thong ke: ");

			int month = Validate.checkThang("Nhap thang can thong ke (1-12): ");

			prstm = conn.prepareStatement(listSqlTopKH);
			prstm.setInt(1, year);
			prstm.setInt(2, month);
			rs = prstm.executeQuery();

			if (rs.next()) {
				String tenKH = rs.getString("TenKH");
				double tongTien = rs.getDouble("TongTien");
				System.out.println("Khach hang " + tenKH + " co tong so tien hang nhieu nhat trong thang " + month + "/"
						+ year + " la: " + tongTien + "VND");
				JOptionPane.getRootFrame().setAlwaysOnTop(true);
				JOptionPane.showMessageDialog(null,
						"Admin nho tang cho khach hang " + tenKH + " 1 voucher free ship cho thang sau!", "Nhac nho",
						JOptionPane.INFORMATION_MESSAGE, null);
			} else {
				System.out.println("Khong co du lieu thong ke cho thang " + month + "/" + year);
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			ConnectionUtil.closeConnection(conn, prstm, rs);
		}
	}

	/**
	 * Cập nhật cột thành tiền cho toàn bộ đơn hàng
	 */
	public static void updateThanhTienHD() {

		Connection conn = ConnectionUtil.getConnection();
		PreparedStatement prstm = null;
		try {

			prstm = conn.prepareStatement(updateSqlThanhTien);
			int numberRecordUpdate = prstm.executeUpdate();
			if (numberRecordUpdate > 0) {
				System.out.println("Cap nhat thanh cong thanh tien cho " + numberRecordUpdate + " hoa don.");
			} else {
				System.out.println("Khong co hoa don nao duoc cap nhat.");
			}

			prstm = conn.prepareStatement(selectSqlKHDisable);
			ResultSet rs = prstm.executeQuery();
			System.out.println("Danh sach cac khach hang khong duoc cap nhat vi bi khoa:");
			while (rs.next()) {
				System.out.println("Ma khach hang: " + rs.getString("maKH") + ", Ten khach hang: "
						+ rs.getString("tenKH") + ", Trang thai: " + rs.getString("trangThaiKH"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConnectionUtil.closeConnection(conn, prstm, null);
		}
	}
}
