package MJP.MVP.giaohangMenu;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Final_Test.ConnectionUtil;
import MJP.MVP.giaohangModel.DonHang;
import MJP.MVP.giaohangModel.KhachHang;

import lib.validate;

public class KhachHangMng {

	public static void menu() {

		Connection conn = ConnectionUtil.getConnection();

		try (Scanner sc = new Scanner(System.in)) {
			KhachHang kh = new KhachHang();
			boolean flag = true;

			int choice;
			do {
				System.out.println();
				System.out.println("Chao mung ban den voi he thong thong tin khach hang ");
				System.out.println("_____________________________");
				System.out.println("1. Dang nhap ID ");
				System.out.println("2. Dang ky thong tin ca nhan  ");
				System.out.println("3. Thoat.");
				System.out.println("______________________________");
				System.out.print("Moi ban chon chuc nang tu 1 - 3 ");
				try {
					choice = Integer.parseInt(sc.nextLine());
				} catch (Exception e) {
					System.out.println("Vui lòng chọn lại các chức năng từ 1 tới 3");
					continue;
				}
				switch (choice) {
				case 1:

					boolean check1 = true;

					try {
						while (check1 == true) {
							System.out.println(
									"===================Chao mung ban den voi chuc nang khach hang cua ung dung giao hang===============");

							String maKH = Validate.checkString("Nhap vao ma khach hang");
							if (validate.checkIDKH(maKH, conn) == true) {
								System.err.println("Ban da dang nhap thanh cong ");
								chucNangKH();
								break;

							} else {
								System.err.println("Ban da nhap sai ID");
							}
							menu();
						}
					} catch (Exception e) {
						System.err.println("Ban da nhap sai ID");

					}

					break;

				case 2:
					insertthongtinKH();
					menu();
					break;
				case 3:
					System.out.println("Cam on ban da su dung he thong");
					flag = false;
					break;

				default:
					System.out.println("Vui long chon lai ");
					break;
				}
			} while (flag);
		}
	}

	public static void chucNangKH() {
		Connection con = ConnectionUtil.getConnection();

		try (Scanner scanner = new Scanner(System.in)) {
			KhachHang kh = new KhachHang();
			int choice;
			do {
				System.out.println();
				System.out.println("Chao mung ban den voi he thong chuc nang khach hang ");
				System.out.println("_____________________________");
				System.out.println("1. Sua thong tin ca nhan  ");
				System.out.println("2. Them don hang moi ");
				System.out.println("3. Sua thong tin don hang ");
				System.out.println("4. Huy don hang");
				System.out.println("5. Xem thong tin don hang");
				System.out.println("6. Thoat.");
				System.out.println("______________________________");
				System.out.print("Moi ban chon chuc nang ");
				try {
					choice = Integer.parseInt(scanner.nextLine());
				} catch (Exception e) {
					System.out.println("Vui long chon lai chuc nang 1 toi 7");
					continue;
				}
				switch (choice) {

				case 1:
					updatethongtinKH();
					break;
				case 2:
					insertDonHang();

					break;
				case 3:
					updateDonHang();
					break;

				case 4:
					updatetrangThaiDonHang();
					break;
				case 5:
					xemthongtinDonHang();
					break;
				case 6:
					menu();
					System.out.println("Cam on ban da su dung he thong");
					return;

				default:
					System.out.println("Vui lòng chọn lại ");
					break;
				}
			} while (true);
		}
	}

	// them thong tin khach hang
	public static void insertthongtinKH() {
		// methods de insert khách hàng
		String sql = "INSERT INTO KHACH_HANG Values(?,?,?,?,?,?)";
		Connection conn = ConnectionUtil.getConnection();
		PreparedStatement prstm = null;
		try {
			prstm = conn.prepareStatement(sql);
			// Nhập các thông tin cần insert vào từ bàn phím

			String maKH = Validate.checkMaKH("Nhap vao ma khach hang");
			while (Validate.checkExistKH(maKH)) {
				System.out.println(" Ma khach hang nay da ton tai moi ban dang nhap lai");
				maKH = Validate.checkMaKH("Nhap vao ma khach hang");

			}

			String tenKH = Validate.checkString("Nhap vao ten");
			String diaChi = Validate.checkString("Nhap vao dia chi giao hang");
			Date ngaySinh = Validate.checkBirthDay("Nhap vao ngay sinh ");
			String gioiTinh = Validate.checkGioiTinh("Nhap vao gioi tinh");
			String sdt = Validate.checkSDT("Nhap vao so dien thoai");

			// gán vào cho database
			prstm.setString(1, maKH);
			prstm.setString(2, tenKH);
			prstm.setString(3, diaChi);
			prstm.setDate(4, ngaySinh);
			prstm.setString(5, gioiTinh);
			prstm.setString(6, sdt);
			int numberRecordInsert = prstm.executeUpdate();
			if (numberRecordInsert > 0) {
				System.out.println("Them thanh cong : " + numberRecordInsert + " thong tin khach hang  ");
			} else {
				System.out.println("Them thong tin khong thanh cong ");
			}
		} catch (SQLException e) {

			e.printStackTrace();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

		}
	}

	public static void updatethongtinKH() {
		// methods de insert don hang mới theo yêu cầu của khách hàng
		String sql = "UPDATE KHACH_HANG set  tenKH = ? ,diaCHi = ? ,ngaySinh = ?, gioiTinh = ?,sdt = ? WHERE maKH = ?";
		Connection conn = ConnectionUtil.getConnection();
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(sql);
			// Nhập các thông tin cần insert vào từ bàn phím

			String maKH = Validate.checkMaKH("Nhap vao ma khach hang");
			String tenKH = Validate.checkString("Nhap vao ten khach hang moi ");
			String diaChi = Validate.checkString("Nhap vao dia chi giao hang moi");
			Date ngaySinh = Validate.checkDate("Nhap vao ngay sinh moi ");
			String gioiTinh = Validate.checkString("Nhap vao gioi tinh moi ");
			String sdt = Validate.checkSDT("Nhap vao so dien thoai moi");

			// gán vào cho database
			ps.setString(1, tenKH);
			ps.setString(2, diaChi);
			ps.setDate(3, ngaySinh);
			ps.setString(4, gioiTinh);
			ps.setString(5, sdt);
			ps.setString(6, maKH);
			int numberRecordInsert = ps.executeUpdate();
			if (numberRecordInsert > 0) {
				System.out.println("cap nhat thanh cong : " + numberRecordInsert + " thong tin ");
			} else {
				System.out.println(" cap nhat  thong tin khong thanh cong");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

		}
	}

	public static void insertDonHang() {
		// methods de insert don hang mới theo yêu cầu của khách hàng
		String sql = "INSERT INTO DON_HANG Values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		Connection conn = ConnectionUtil.getConnection();
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(sql);
			// Nhập các thông tin cần insert vào từ bàn phím
			String maDH = Validate.checkMaDH("Nhap vao ma don hang");
			String maKH = Validate.checkMaKH("Nhap vao ma khach hang");
			String maDV = Validate.checkMaDV("Nhap vao ma dich vu");
			String maLH = Validate.checkMaLH("Nhap vao ma loai hang");
			String maPT = Validate.checkMaPT("Nhap vao ma phuong thuc thanh toan");
			String maShipper = Validate.checkString("Nhap vao ma shipper ");
			Date ngayGiaoHang = Validate.checkDate("Nhap vao ngay giao hang");
			String diaChiGH = Validate.checkString("Nhap vao dia chi giao hang ");
			String tenMonHang = Validate.checkString("Nhap vao ten mon hang ");

			String sdt = Validate.checkSDT("Nhap vao so dien thoai ");
			String tenNguoiNhan = Validate.checkString("Nhap vao ten ng nhan ");
			String trangThaiPheDuyet = Validate.checkString("Nhap vao trang thai phe duyet ");
			String trangThaiGiaoHang = Validate.checkString("Nhap vao trang thai GH ");
			String trangThaiDonHang = Validate.checkString("Nhap vao trang thai don hang ");

			// gán vào cho database
			ps.setString(1, maDH);
			ps.setString(2, maKH);
			ps.setString(3, maDV);
			ps.setString(4, maLH);
			ps.setString(5, maPT);
			ps.setString(6, maShipper);
			ps.setDate(7, ngayGiaoHang);
			ps.setString(8, diaChiGH);
			ps.setString(9, tenMonHang);
			ps.setString(10, sdt);
			ps.setString(11, tenNguoiNhan);
			ps.setString(12, trangThaiPheDuyet);
			ps.setString(13, trangThaiGiaoHang);

			ps.setString(14, trangThaiDonHang);

			int numberRecordInsert = ps.executeUpdate();
			if (numberRecordInsert > 0) {
				System.out.println("Them thanh cong : " + numberRecordInsert + " don hang ");
			} else {
				System.out.println("Them don hang khong thanh cong");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

		}
	}

	// update don hang

	public static void updateDonHang() {
		// methods de insert don hang mới theo yêu cầu của khách hàng
		String sql = "UPDATE DON_HANG set maKH = ? ,maDV = ? ,maLH = ? , maPT = ?, maShipper = ?  ,ngayGiaoHang = ?, diaChi = ?,tenMonHang = ?,sdt = ?,tenNguoiNhan = ?, trangThaiPheDuyet = ?, trangThaiGiaoHang = ? ,trangThaiDonHang = ? WHERE maDH = ?";
		Connection conn = ConnectionUtil.getConnection();
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(sql);
			// Nhập các thông tin cần insert vào từ bàn phím
			String maDH = Validate.checkMaDH("Nhap vao ma don hang");
			//validate maKH
			String maKH = Validate.checkMaKH("Nhap vao ma khach hang moi");
			String maDV = Validate.checkMaDV("Nhap vao ma dich vu moi");
			String maLH = Validate.checkMaLH("Nhap vao ma loai hang moi ");
			String maPT = Validate.checkMaPT("Nhap vao ma phuong thuc thanh toan moi");
			//shipper = null
			String maShipper = Validate.checkMaShipper("Nhap vao ma shipper moi");
			Date ngayGiaoHang = Validate.checkDate("Nhap vao ngay giao hang moi");
			String diaChi = Validate.checkString("Nhap vao dia chi giao hang moi");
			String tenMonHang = Validate.checkString("Nhap vao ten mon hang moi ");
			String sdt = Validate.checkSDT("Nhap vao so dien thoai moi");
			String tenNguoiNhan = Validate.checkString("Nhap vao ten ng nhan moi");
			// trang thai PD de mac dinh
			String trangThaiPheDuyet = Validate.checkString("Nhap vao trang thai phe duyet moi");
			//trang thai GH de mac dinh
			String trangThaiGiaoHang = Validate.checkString("Nhap vao trang thai GH moi ");
			String trangThaiDonHang = Validate.checkString("Nhap vao trang thai don hang moi");

			// gán vào cho database
			ps.setString(1, maKH);
			ps.setString(2, maDV);
			ps.setString(3, maLH);
			ps.setString(4, maPT);
			ps.setString(5, maShipper);
			ps.setDate(6, ngayGiaoHang);
			ps.setString(7, diaChi);
			ps.setString(8, tenMonHang);
			ps.setString(9, sdt);
			ps.setString(10, tenNguoiNhan);
			ps.setString(11, trangThaiPheDuyet);
			ps.setString(12, trangThaiGiaoHang);
			ps.setString(13, trangThaiDonHang);
			ps.setString(14, maDH);

			int numberRecordInsert = ps.executeUpdate();
			if (numberRecordInsert > 0) {
				System.out.println("cap nhat thanh cong : " + numberRecordInsert + " don hang ");
			} else {
				System.out.println(" cap nhat don hang khong thanh cong");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

		}
	}

	// cap nhat trang thai don hang
	public static void updatetrangThaiDonHang() {
		// methods de insert don hang mới theo yêu cầu của khách hàng
		String sql = "UPDATE DON_HANG set trangThaiDonHang = ? WHERE maDH = ?";
		Connection conn = ConnectionUtil.getConnection();
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(sql);
			// Nhập các thông tin cần insert vào từ bàn phím
			String maDH = Validate.checkMaDH("Nhap vao ma don hang");
			// de mac dinh la da huy
			String trangThaiDonHang = Validate.checkString("Nhap vao trang thai don hang moi");

			// gán vào cho database
			ps.setString(2, maDH);
			ps.setString(1, trangThaiDonHang);

			int numberRecordInsert = ps.executeUpdate();
			if (numberRecordInsert > 0) {
				System.out.println("Them trang thaithanh cong : " + numberRecordInsert + " don hang ");
			} else {
				System.out.println("Them trang thai don hang khong thanh cong");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

		}
	}

	public static void xemthongtinDonHang() {
		// methods de insert don hang mới theo yêu cầu của khách hàng
		String sql = "SELECT * FROM DON_HANG WHERE maKH = ? ";
		Connection conn = ConnectionUtil.getConnection();

		PreparedStatement ps = null;
		try {
			String maKH = Validate.checkMaKH("Nhap vao maKH");

			ps = conn.prepareStatement(sql);
			ps.setString(1, maKH);
			// Nhập các thông tin cần insert vào từ bàn phím
			ResultSet rs = ps.executeQuery();
			List<DonHang> ls = new ArrayList<DonHang>();
			DonHang dk = new DonHang();
			if (rs.isBeforeFirst()) {
				while (rs.next()) {
					dk.setMaDH(rs.getString("maDH"));
					dk.setMaKH(rs.getString("maKH"));
					dk.setMaDV(rs.getString("maDV"));
					dk.setMaLH(rs.getString("maLH"));
					dk.setMaPT(rs.getString("maPT"));
					dk.setMaShipper(rs.getString("maShipper"));
					dk.setNgayGiaoHang(rs.getDate("ngayGiaoHang"));
					dk.setDiaChi(rs.getString("diaChi"));
					dk.setTenMonHang(rs.getString("tenMonHang"));
					dk.setSdt(rs.getString("sdt"));
					dk.setTenNguoiNhan(rs.getString("tenNguoiNhan"));
					dk.setTrangThaiPheDuyet(rs.getString("trangThaiPheDuyet"));
					dk.setTrangThaiGiaoHang(rs.getString("trangThaiGiaoHang"));
					dk.setTrangThaiDonHang(rs.getString("trangThaiDonHang"));

					System.out.println(dk);
				}
//						for (DON_HANG don_HANG : ls) {
//						
				//
//								System.out.println(don_HANG);
//							}
				System.out.println("===================================");
			}

			else {
				System.out.println("Khong co don hang nao ton tai voi maKH la :" + maKH);
			}
			// gán vào cho database

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

		}

	}

}
