package MJP.MVP.giaohang;

import java.sql.SQLException;
import java.util.Scanner;

import MJP.MVP.giaohangMenu.AdminMngKH;
import MJP.MVP.giaohangMenu.AdminMngShipper;
import lib.ShipperMng;
import lib.adminMng;
import lib.adminMng2;
import lib.khachHangMng;

public class giaoHangMng {
	public static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		AdminMngShipper adminMngShipper= new AdminMngShipper();
		int choice;
		do {
			System.out.println();
			System.out.println("Chao mung ban den voi he thong quan ly giao hang: ");
			System.out.println("_____________________________");
			System.out.println("1. Admin quan ly shipper");
			System.out.println("2. Admin quan ly khach hang ");
			System.out.println("3. Khach hang");
			System.out.println("4. Shipper");
			System.out.println("5. Thoat");
			System.out.println("______________________________");
			System.out.print("Moi ban chon dung vai tro minh muon dang nhap he thong: ");
			try {
				choice = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("Vui long nhap lai su lua chon cua ban la so nguyen duong");
				continue;
			}
			switch (choice) {
			case 1:
				AdminMngShipper adminMng= new AdminMngShipper();
				adminMng.admin();
				break;
			case 2:
				AdminMngKH.adminMenu2();
				break;
			case 3:
				khachHangMng.menu();
				break;
			case 4:
				try {
					ShipperMng.chucnangShipper();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				break;

			case 5:
				System.out.println("Cảm ơn bạn đã sử dụng hệ thống");
				return;
			default:
				System.out.println("Vui lòng chọn lại đúng vai trò của bạn");
				break;
			}
		} while (true);

	}

}
