package MJP.MVP.giaohang;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnectionUtil {

	private static final String DB_URL = "jdbc:sqlserver://localhost:1433;databaseName=MJP_MVP_GIAOHANG;encrypt=true;trustServerCertificate=true;";

	private static final String USERNAME = "dr";

	private static final String PASSWORD = "1234567A@";

	public static Connection getConnection() {

		Connection conn = null;

		try {

			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			System.out.println("Ket noi DB that bai");
		}

		return conn;

	}

	public static void closeConnection(Connection c, PreparedStatement pstm, ResultSet resultSet) {
		try {
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();

				}
				if (pstm != null) {
					pstm.close();
				}
				if (c != null) {
					c.close();
				}
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {

		Connection con = getConnection();

		if (con != null) {
			System.out.println("Ket noi DB thanh cong");
		}
//		try {
//			Statement stmt = con.createStatement();
//			ResultSet rs = stmt.executeQuery("SELECT * FROM THIENTHAN2");
//			rs.absolute(2);
//			System.out.println(rs.getInt(1));
//		} catch (SQLException e) {
//			System.out.println("connect failure!");
//			e.printStackTrace();
//			
//		}


	}

}
